import boto3, botocore
import os
import hashlib



s3= boto3.client('s3')


def handler(event,context):
    msg= "hello world"
    print(msg)
    path = (event['Records'][0]['s3']['object']['key'])
    bucket = (event['Records'][0]['s3']['bucket']['name'])
    flname = path.split("/")[-1]
    filetype = flname.split('.')[-1]
    #print(f'You uploaded {flname} in {bucket} and the file type is {filetype}')
    #print(path)
    
    os.makedirs(os.path.dirname(f'/tmp/{flname}'), exist_ok=True)
    s3.download_file(bucket, path, f'/tmp/{flname}')
    all_line = 0
    real_line = 0
    Hashes = []
    
    with open(f'/tmp/{flname}') as f:
        for line in f:
            all_line += 1
            if line.strip():
                real_line += 1
                flname2 = flname.split('.')
                flname2[0] = f'{flname2[0]}-{real_line}'
                flname2 = '.'.join(flname2)
                
                hash_file = hashlib.md5()
                os.makedirs(os.path.dirname(f'/tmp/{flname2}'), exist_ok=True)
                with open(f'/tmp/{flname2}', 'w+') as ff:
                    ff.write(line)
                ff.close
                newpath = f'lines/{flname2}'
                s3.upload_file(Bucket=f'{bucket}-2', Key=newpath, Filename=f'/tmp/{flname2}')
                
                with open(f'/tmp/{flname2}', 'rb') as ff2:
                    buf = ff2.read()
                    hash_file.update(buf)
                    Hashes.append(hash_file.hexdigest())
                
                flname2 = flname.split('.')
                flname2[0] = f'{flname2[0]}-{real_line}-hash'
                flname2 = '.'.join(flname2)
                
                os.makedirs(os.path.dirname(f'/tmp/{flname2}'), exist_ok=True)
                with open(f'/tmp/{flname2}', 'w+') as ff_hash:
                    ff_hash.write(hash_file.hexdigest())
                ff_hash.close
                newpath = f'lines/{flname2}'
                s3.upload_file(Bucket=bucket, Key=newpath, Filename=f'/tmp/{flname2}')

                
    
    count = 0
    seen = []
    dupes = []
    
    for x in Hashes:
        if x not in seen:
            seen.append(x)
        else:
            try:
                dupes.append(count)
                dupes.append(Hashes.index(x))
                Hashes[Hashes.index(x)] = count
            except:
                print('Error here')
        count += 1
        
    empty_line= all_line - real_line
    print(f'total lines = {all_line} \n')
    print(f'real lines = {real_line} \n')
    print(f'empty lines = {empty_line} \n')
    
    print("The identical filer are :")
    for x in dupes:
        flname2 = flname.split('.')
        flname2[0] = f'{flname2[0]}-{x}-hash'
        flname2 = '.'.join(flname2)
        print(f'{flname2} , ')
    print(' \n')

    if len(dupes) > 1:
        remove_line = 1
        with open(f'/tmp/{flname}') as f:
            for line in f:
                if remove line in dupes[1:]:
                    line = ''
                    f.write(line)
                remove_line += 1
        f.close

        flname3 = flname.split('.')
        flname3[0] = f'{flname3[0]}-clean'
        flname3 = '.'.join(flname3)
        newpath = f'cleaned/{flname2}'
        s3.upload_file(Bucket=bucket, Key=newpath, Filename=f'/tmp/{flname}')

        
    
    return event 